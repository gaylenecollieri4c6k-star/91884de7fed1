// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("infer analyze\n", stdout);
  return lionss_run_workload("infer-analyze");
}
