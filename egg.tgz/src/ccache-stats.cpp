// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("ccache stats"); }
int main(){
  announce();
  return lionss_run_workload("ccache-stats");
}
