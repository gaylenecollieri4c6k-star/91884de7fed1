// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("cppcheck"); }
int main(){
  announce();
  return lionss_run_workload("cppcheck");
}
