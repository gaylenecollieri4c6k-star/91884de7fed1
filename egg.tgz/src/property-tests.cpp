// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("property tests\n", stdout);
  return lionss_run_workload("property-tests");
}
